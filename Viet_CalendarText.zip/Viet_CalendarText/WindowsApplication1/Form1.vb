﻿Public Class Form1

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtDayOfWeek.Clear()
        txtMonth.Clear()
        txtDayofMonth.Clear()
        txtYear.Clear()
        lblDateString.Text = String.Empty
        txtDayOfWeek.Focus()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub lblDateString_Click(sender As Object, e As EventArgs) Handles lblDateString.Click
        

    End Sub

    Private Sub txtDayOfWeek_TextChanged(sender As Object, e As EventArgs) Handles txtDayOfWeek.TextChanged

    End Sub

    Private Sub btnShowDate_Click(sender As Object, e As EventArgs) Handles btnShowDate.Click
        lblDateString.Text = txtDayOfWeek.Text & "," &
            txtMonth.Text & " " &
            txtDayofMonth.Text & " ,"& txtYear.Text

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
