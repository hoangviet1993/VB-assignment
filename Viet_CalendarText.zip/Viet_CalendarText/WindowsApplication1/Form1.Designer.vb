﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblEnterDay = New System.Windows.Forms.Label()
        Me.lblEnterMonth = New System.Windows.Forms.Label()
        Me.lblEnterYear = New System.Windows.Forms.Label()
        Me.lblEnterDayofmonth = New System.Windows.Forms.Label()
        Me.btnShowDate = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.txtDayOfWeek = New System.Windows.Forms.TextBox()
        Me.txtMonth = New System.Windows.Forms.TextBox()
        Me.txtDayofMonth = New System.Windows.Forms.TextBox()
        Me.txtYear = New System.Windows.Forms.TextBox()
        Me.lblDateString = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblEnterDay
        '
        Me.lblEnterDay.AutoSize = True
        Me.lblEnterDay.Location = New System.Drawing.Point(34, 28)
        Me.lblEnterDay.Name = "lblEnterDay"
        Me.lblEnterDay.Size = New System.Drawing.Size(129, 13)
        Me.lblEnterDay.TabIndex = 0
        Me.lblEnterDay.Text = "Enter the day of the week"
        '
        'lblEnterMonth
        '
        Me.lblEnterMonth.AutoSize = True
        Me.lblEnterMonth.Location = New System.Drawing.Point(34, 53)
        Me.lblEnterMonth.Name = "lblEnterMonth"
        Me.lblEnterMonth.Size = New System.Drawing.Size(82, 13)
        Me.lblEnterMonth.TabIndex = 1
        Me.lblEnterMonth.Text = "Enter the month"
        '
        'lblEnterYear
        '
        Me.lblEnterYear.AutoSize = True
        Me.lblEnterYear.Location = New System.Drawing.Point(34, 107)
        Me.lblEnterYear.Name = "lblEnterYear"
        Me.lblEnterYear.Size = New System.Drawing.Size(73, 13)
        Me.lblEnterYear.TabIndex = 2
        Me.lblEnterYear.Text = "Enter the year"
        '
        'lblEnterDayofmonth
        '
        Me.lblEnterDayofmonth.AutoSize = True
        Me.lblEnterDayofmonth.Location = New System.Drawing.Point(34, 78)
        Me.lblEnterDayofmonth.Name = "lblEnterDayofmonth"
        Me.lblEnterDayofmonth.Size = New System.Drawing.Size(132, 13)
        Me.lblEnterDayofmonth.TabIndex = 3
        Me.lblEnterDayofmonth.Text = "Enter the day of the month"
        '
        'btnShowDate
        '
        Me.btnShowDate.Location = New System.Drawing.Point(63, 193)
        Me.btnShowDate.Name = "btnShowDate"
        Me.btnShowDate.Size = New System.Drawing.Size(77, 30)
        Me.btnShowDate.TabIndex = 4
        Me.btnShowDate.Text = "Show Date"
        Me.btnShowDate.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(146, 193)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(72, 30)
        Me.btnClear.TabIndex = 5
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(224, 193)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(73, 30)
        Me.btnExit.TabIndex = 6
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'txtDayOfWeek
        '
        Me.txtDayOfWeek.Location = New System.Drawing.Point(186, 28)
        Me.txtDayOfWeek.Name = "txtDayOfWeek"
        Me.txtDayOfWeek.Size = New System.Drawing.Size(132, 20)
        Me.txtDayOfWeek.TabIndex = 7
        '
        'txtMonth
        '
        Me.txtMonth.Location = New System.Drawing.Point(186, 54)
        Me.txtMonth.Name = "txtMonth"
        Me.txtMonth.Size = New System.Drawing.Size(132, 20)
        Me.txtMonth.TabIndex = 8
        '
        'txtDayofMonth
        '
        Me.txtDayofMonth.Location = New System.Drawing.Point(186, 80)
        Me.txtDayofMonth.Name = "txtDayofMonth"
        Me.txtDayofMonth.Size = New System.Drawing.Size(132, 20)
        Me.txtDayofMonth.TabIndex = 9
        '
        'txtYear
        '
        Me.txtYear.Location = New System.Drawing.Point(186, 107)
        Me.txtYear.Name = "txtYear"
        Me.txtYear.Size = New System.Drawing.Size(132, 20)
        Me.txtYear.TabIndex = 10
        '
        'lblDateString
        '
        Me.lblDateString.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDateString.Location = New System.Drawing.Point(58, 151)
        Me.lblDateString.Name = "lblDateString"
        Me.lblDateString.Size = New System.Drawing.Size(239, 19)
        Me.lblDateString.TabIndex = 11
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(331, 295)
        Me.Controls.Add(Me.lblDateString)
        Me.Controls.Add(Me.txtYear)
        Me.Controls.Add(Me.txtDayofMonth)
        Me.Controls.Add(Me.txtMonth)
        Me.Controls.Add(Me.txtDayOfWeek)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnShowDate)
        Me.Controls.Add(Me.lblEnterDayofmonth)
        Me.Controls.Add(Me.lblEnterYear)
        Me.Controls.Add(Me.lblEnterMonth)
        Me.Controls.Add(Me.lblEnterDay)
        Me.Name = "Form1"
        Me.Text = "Date String"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblEnterDay As System.Windows.Forms.Label
    Friend WithEvents lblEnterMonth As System.Windows.Forms.Label
    Friend WithEvents lblEnterYear As System.Windows.Forms.Label
    Friend WithEvents lblEnterDayofmonth As System.Windows.Forms.Label
    Friend WithEvents btnShowDate As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents txtDayOfWeek As System.Windows.Forms.TextBox
    Friend WithEvents txtMonth As System.Windows.Forms.TextBox
    Friend WithEvents txtDayofMonth As System.Windows.Forms.TextBox
    Friend WithEvents txtYear As System.Windows.Forms.TextBox
    Friend WithEvents lblDateString As System.Windows.Forms.Label

End Class
