﻿Public Class Form1

    Private Sub btnConvert_Click(sender As Object, e As EventArgs) Handles btnConvert.Click
        Dim sngCelsius As Single
        Dim sngFahrenheit As Single
        Try
            sngCelsius = CSng(txtCelsius.Text)
            sngFahrenheit = sngCelsius * 1.8 + 32
            lblResult.Visible = True
            lblResult.Text = CStr(sngFahrenheit)

            txtCelsius.Focus()
        Catch ex As InvalidCastException
            MessageBox.Show("Please enter numeric value")
        End Try
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub txtCelsis_Click(sender As Object, e As EventArgs) Handles txtCelsius.Click
        'Clear all text
        txtCelsius.Text = String.Empty
        lblResult.Visible = False
    End Sub


End Class
