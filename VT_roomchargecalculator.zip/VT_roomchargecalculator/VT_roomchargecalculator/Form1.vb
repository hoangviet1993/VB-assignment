﻿Public Class Form1

    Dim decRoomCharges, decAddCharges, decSubTotal, decTax, decTotal As Decimal
    Dim decTAX_RATE As Decimal = 0.08D

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblDateToday.Text = Now.ToString("D")
        lblTimeToday.Text = Now.ToString("T")
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Try
            decRoomCharges = CDec(txtNights.Text) * CDec(txtNightlyCharge.Text)
            lblRoomCharges.Text = decRoomCharges.ToString("c")
            decAddCharges = CDec(txtRoomService.Text) + CDec(txtTelephone.Text) + CDec(txtMisc.Text)
            lblAddCharges.Text = decAddCharges.ToString("c")
            decSubTotal = decRoomCharges + decAddCharges
            lblSubTotal.Text = decSubTotal.ToString("c")
            decTax = decSubTotal * decTAX_RATE
            lblTax.Text = decTax.ToString("c")
            decTotal = decSubTotal + decTax
            lblTotal.Text = decTotal.ToString("c")
            lblRoomCharges.Visible = True
            lblAddCharges.Visible = True
            lblSubTotal.Visible = True
            lblTotal.Visible = True
            lblTax.Visible = True
        Catch Ex As InvalidCastException
            MessageBox.Show("Please enter numeric value(s).")
        End Try
    End Sub

    Private Sub txtNights_Click(sender As Object, e As EventArgs) Handles txtNights.Click
        txtNights.Clear()
        txtMisc.Clear()
        txtNightlyCharge.Clear()
        txtRoomService.Clear()
        txtTelephone.Clear()
        lblAddCharges.Text = String.Empty
        lblRoomCharges.Text = String.Empty
        lblSubTotal.Text = String.Empty
        lblTotal.Text = String.Empty
        lblTax.Text = String.Empty
        txtNights.Focus()
        lblDateToday.Text = Now.ToString("D")
        lblTimeToday.Text = Now.ToString("T")
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtNights.Clear()
        txtMisc.Clear()
        txtNightlyCharge.Clear()
        txtRoomService.Clear()
        txtTelephone.Clear()
        lblAddCharges.Text = String.Empty
        lblRoomCharges.Text = String.Empty
        lblSubTotal.Text = String.Empty
        lblTotal.Text = String.Empty
        lblTax.Text = String.Empty
        txtNights.Focus()
        lblDateToday.Text = Now.ToString("D")
        lblTimeToday.Text = Now.ToString("T")
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

End Class
