﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblTodaydateText = New System.Windows.Forms.Label()
        Me.lblTimeText = New System.Windows.Forms.Label()
        Me.lblRoomchargesText = New System.Windows.Forms.Label()
        Me.lblAdditionalchargeText = New System.Windows.Forms.Label()
        Me.lblSubtotalText = New System.Windows.Forms.Label()
        Me.lblTaxText = New System.Windows.Forms.Label()
        Me.lblTotalchargesText = New System.Windows.Forms.Label()
        Me.lblDateToday = New System.Windows.Forms.Label()
        Me.lblTimeToday = New System.Windows.Forms.Label()
        Me.lblRoominfoText = New System.Windows.Forms.Label()
        Me.lblNightsText = New System.Windows.Forms.Label()
        Me.lblNightlycharge = New System.Windows.Forms.Label()
        Me.lblTelephoneText = New System.Windows.Forms.Label()
        Me.lblRoomService = New System.Windows.Forms.Label()
        Me.lblMiscText = New System.Windows.Forms.Label()
        Me.grpTotalCharges = New System.Windows.Forms.GroupBox()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.lblTax = New System.Windows.Forms.Label()
        Me.lblSubTotal = New System.Windows.Forms.Label()
        Me.lblAddCharges = New System.Windows.Forms.Label()
        Me.lblRoomCharges = New System.Windows.Forms.Label()
        Me.GroupgrpBox1 = New System.Windows.Forms.GroupBox()
        Me.txtNights = New System.Windows.Forms.TextBox()
        Me.txtNightlyCharge = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtMisc = New System.Windows.Forms.TextBox()
        Me.txtTelephone = New System.Windows.Forms.TextBox()
        Me.txtRoomService = New System.Windows.Forms.TextBox()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblHighlanderHotel = New System.Windows.Forms.Label()
        Me.grpTotalCharges.SuspendLayout()
        Me.GroupgrpBox1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblTodaydateText
        '
        Me.lblTodaydateText.AutoSize = True
        Me.lblTodaydateText.Location = New System.Drawing.Point(141, 75)
        Me.lblTodaydateText.Name = "lblTodaydateText"
        Me.lblTodaydateText.Size = New System.Drawing.Size(70, 13)
        Me.lblTodaydateText.TabIndex = 0
        Me.lblTodaydateText.Text = "Today's Date"
        '
        'lblTimeText
        '
        Me.lblTimeText.AutoSize = True
        Me.lblTimeText.Location = New System.Drawing.Point(141, 88)
        Me.lblTimeText.Name = "lblTimeText"
        Me.lblTimeText.Size = New System.Drawing.Size(30, 13)
        Me.lblTimeText.TabIndex = 0
        Me.lblTimeText.Text = "Time"
        '
        'lblRoomchargesText
        '
        Me.lblRoomchargesText.AutoSize = True
        Me.lblRoomchargesText.Location = New System.Drawing.Point(44, 52)
        Me.lblRoomchargesText.Name = "lblRoomchargesText"
        Me.lblRoomchargesText.Size = New System.Drawing.Size(72, 13)
        Me.lblRoomchargesText.TabIndex = 0
        Me.lblRoomchargesText.Text = "Room Charge"
        '
        'lblAdditionalchargeText
        '
        Me.lblAdditionalchargeText.AutoSize = True
        Me.lblAdditionalchargeText.Location = New System.Drawing.Point(44, 76)
        Me.lblAdditionalchargeText.Name = "lblAdditionalchargeText"
        Me.lblAdditionalchargeText.Size = New System.Drawing.Size(90, 13)
        Me.lblAdditionalchargeText.TabIndex = 0
        Me.lblAdditionalchargeText.Text = "Additional Charge"
        '
        'lblSubtotalText
        '
        Me.lblSubtotalText.AutoSize = True
        Me.lblSubtotalText.Location = New System.Drawing.Point(44, 104)
        Me.lblSubtotalText.Name = "lblSubtotalText"
        Me.lblSubtotalText.Size = New System.Drawing.Size(46, 13)
        Me.lblSubtotalText.TabIndex = 0
        Me.lblSubtotalText.Text = "Subtotal"
        '
        'lblTaxText
        '
        Me.lblTaxText.AutoSize = True
        Me.lblTaxText.Location = New System.Drawing.Point(44, 130)
        Me.lblTaxText.Name = "lblTaxText"
        Me.lblTaxText.Size = New System.Drawing.Size(25, 13)
        Me.lblTaxText.TabIndex = 0
        Me.lblTaxText.Text = "Tax"
        '
        'lblTotalchargesText
        '
        Me.lblTotalchargesText.AutoSize = True
        Me.lblTotalchargesText.Location = New System.Drawing.Point(44, 156)
        Me.lblTotalchargesText.Name = "lblTotalchargesText"
        Me.lblTotalchargesText.Size = New System.Drawing.Size(73, 13)
        Me.lblTotalchargesText.TabIndex = 0
        Me.lblTotalchargesText.Text = "Total Charges"
        '
        'lblDateToday
        '
        Me.lblDateToday.AutoSize = True
        Me.lblDateToday.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDateToday.Location = New System.Drawing.Point(254, 75)
        Me.lblDateToday.Name = "lblDateToday"
        Me.lblDateToday.Size = New System.Drawing.Size(34, 13)
        Me.lblDateToday.TabIndex = 0
        Me.lblDateToday.Text = "Date"
        '
        'lblTimeToday
        '
        Me.lblTimeToday.AutoSize = True
        Me.lblTimeToday.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTimeToday.Location = New System.Drawing.Point(254, 88)
        Me.lblTimeToday.Name = "lblTimeToday"
        Me.lblTimeToday.Size = New System.Drawing.Size(34, 13)
        Me.lblTimeToday.TabIndex = 0
        Me.lblTimeToday.Text = "Time"
        '
        'lblRoominfoText
        '
        Me.lblRoominfoText.AutoSize = True
        Me.lblRoominfoText.Location = New System.Drawing.Point(6, 30)
        Me.lblRoominfoText.Name = "lblRoominfoText"
        Me.lblRoominfoText.Size = New System.Drawing.Size(0, 13)
        Me.lblRoominfoText.TabIndex = 0
        '
        'lblNightsText
        '
        Me.lblNightsText.AutoSize = True
        Me.lblNightsText.Location = New System.Drawing.Point(35, 43)
        Me.lblNightsText.Name = "lblNightsText"
        Me.lblNightsText.Size = New System.Drawing.Size(37, 13)
        Me.lblNightsText.TabIndex = 0
        Me.lblNightsText.Text = "Nights"
        '
        'lblNightlycharge
        '
        Me.lblNightlycharge.AutoSize = True
        Me.lblNightlycharge.Location = New System.Drawing.Point(35, 86)
        Me.lblNightlycharge.Name = "lblNightlycharge"
        Me.lblNightlycharge.Size = New System.Drawing.Size(76, 13)
        Me.lblNightlycharge.TabIndex = 0
        Me.lblNightlycharge.Text = "Nightly Charge"
        '
        'lblTelephoneText
        '
        Me.lblTelephoneText.AutoSize = True
        Me.lblTelephoneText.Location = New System.Drawing.Point(22, 71)
        Me.lblTelephoneText.Name = "lblTelephoneText"
        Me.lblTelephoneText.Size = New System.Drawing.Size(58, 13)
        Me.lblTelephoneText.TabIndex = 0
        Me.lblTelephoneText.Text = "Telephone"
        '
        'lblRoomService
        '
        Me.lblRoomService.AutoSize = True
        Me.lblRoomService.Location = New System.Drawing.Point(22, 38)
        Me.lblRoomService.Name = "lblRoomService"
        Me.lblRoomService.Size = New System.Drawing.Size(74, 13)
        Me.lblRoomService.TabIndex = 0
        Me.lblRoomService.Text = "Room Service"
        '
        'lblMiscText
        '
        Me.lblMiscText.AutoSize = True
        Me.lblMiscText.Location = New System.Drawing.Point(26, 103)
        Me.lblMiscText.Name = "lblMiscText"
        Me.lblMiscText.Size = New System.Drawing.Size(29, 13)
        Me.lblMiscText.TabIndex = 0
        Me.lblMiscText.Text = "Misc"
        '
        'grpTotalCharges
        '
        Me.grpTotalCharges.Controls.Add(Me.lblTotal)
        Me.grpTotalCharges.Controls.Add(Me.lblTax)
        Me.grpTotalCharges.Controls.Add(Me.lblSubTotal)
        Me.grpTotalCharges.Controls.Add(Me.lblAddCharges)
        Me.grpTotalCharges.Controls.Add(Me.lblRoomCharges)
        Me.grpTotalCharges.Controls.Add(Me.lblRoomchargesText)
        Me.grpTotalCharges.Controls.Add(Me.lblSubtotalText)
        Me.grpTotalCharges.Controls.Add(Me.lblTaxText)
        Me.grpTotalCharges.Controls.Add(Me.lblTotalchargesText)
        Me.grpTotalCharges.Controls.Add(Me.lblAdditionalchargeText)
        Me.grpTotalCharges.Location = New System.Drawing.Point(94, 330)
        Me.grpTotalCharges.Name = "grpTotalCharges"
        Me.grpTotalCharges.Size = New System.Drawing.Size(422, 183)
        Me.grpTotalCharges.TabIndex = 3
        Me.grpTotalCharges.TabStop = False
        Me.grpTotalCharges.Text = "Total Charges"
        '
        'lblTotal
        '
        Me.lblTotal.AutoSize = True
        Me.lblTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotal.Location = New System.Drawing.Point(251, 154)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(41, 15)
        Me.lblTotal.TabIndex = 5
        Me.lblTotal.Text = "Label5"
        Me.lblTotal.Visible = False
        '
        'lblTax
        '
        Me.lblTax.AutoSize = True
        Me.lblTax.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTax.Location = New System.Drawing.Point(251, 128)
        Me.lblTax.Name = "lblTax"
        Me.lblTax.Size = New System.Drawing.Size(41, 15)
        Me.lblTax.TabIndex = 4
        Me.lblTax.Text = "Label4"
        Me.lblTax.Visible = False
        '
        'lblSubTotal
        '
        Me.lblSubTotal.AutoSize = True
        Me.lblSubTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSubTotal.Location = New System.Drawing.Point(251, 102)
        Me.lblSubTotal.Name = "lblSubTotal"
        Me.lblSubTotal.Size = New System.Drawing.Size(41, 15)
        Me.lblSubTotal.TabIndex = 3
        Me.lblSubTotal.Text = "Label3"
        Me.lblSubTotal.Visible = False
        '
        'lblAddCharges
        '
        Me.lblAddCharges.AutoSize = True
        Me.lblAddCharges.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAddCharges.Location = New System.Drawing.Point(251, 76)
        Me.lblAddCharges.Name = "lblAddCharges"
        Me.lblAddCharges.Size = New System.Drawing.Size(41, 15)
        Me.lblAddCharges.TabIndex = 2
        Me.lblAddCharges.Text = "Label2"
        Me.lblAddCharges.Visible = False
        '
        'lblRoomCharges
        '
        Me.lblRoomCharges.AutoSize = True
        Me.lblRoomCharges.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRoomCharges.Location = New System.Drawing.Point(251, 50)
        Me.lblRoomCharges.Name = "lblRoomCharges"
        Me.lblRoomCharges.Size = New System.Drawing.Size(41, 15)
        Me.lblRoomCharges.TabIndex = 1
        Me.lblRoomCharges.Text = "Label1"
        Me.lblRoomCharges.Visible = False
        '
        'GroupgrpBox1
        '
        Me.GroupgrpBox1.Controls.Add(Me.txtNights)
        Me.GroupgrpBox1.Controls.Add(Me.txtNightlyCharge)
        Me.GroupgrpBox1.Controls.Add(Me.lblRoominfoText)
        Me.GroupgrpBox1.Controls.Add(Me.lblNightsText)
        Me.GroupgrpBox1.Controls.Add(Me.lblNightlycharge)
        Me.GroupgrpBox1.Location = New System.Drawing.Point(31, 146)
        Me.GroupgrpBox1.Name = "GroupgrpBox1"
        Me.GroupgrpBox1.Size = New System.Drawing.Size(223, 154)
        Me.GroupgrpBox1.TabIndex = 1
        Me.GroupgrpBox1.TabStop = False
        Me.GroupgrpBox1.Text = "Room Information"
        '
        'txtNights
        '
        Me.txtNights.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtNights.Location = New System.Drawing.Point(146, 45)
        Me.txtNights.Name = "txtNights"
        Me.txtNights.Size = New System.Drawing.Size(50, 20)
        Me.txtNights.TabIndex = 1
        '
        'txtNightlyCharge
        '
        Me.txtNightlyCharge.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtNightlyCharge.Location = New System.Drawing.Point(146, 86)
        Me.txtNightlyCharge.Name = "txtNightlyCharge"
        Me.txtNightlyCharge.Size = New System.Drawing.Size(50, 20)
        Me.txtNightlyCharge.TabIndex = 2
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtMisc)
        Me.GroupBox1.Controls.Add(Me.txtTelephone)
        Me.GroupBox1.Controls.Add(Me.txtRoomService)
        Me.GroupBox1.Controls.Add(Me.lblRoomService)
        Me.GroupBox1.Controls.Add(Me.lblTelephoneText)
        Me.GroupBox1.Controls.Add(Me.lblMiscText)
        Me.GroupBox1.Location = New System.Drawing.Point(316, 146)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(200, 137)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Additional Charge"
        '
        'txtMisc
        '
        Me.txtMisc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtMisc.Location = New System.Drawing.Point(115, 103)
        Me.txtMisc.Name = "txtMisc"
        Me.txtMisc.Size = New System.Drawing.Size(50, 20)
        Me.txtMisc.TabIndex = 3
        '
        'txtTelephone
        '
        Me.txtTelephone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtTelephone.Location = New System.Drawing.Point(115, 71)
        Me.txtTelephone.Name = "txtTelephone"
        Me.txtTelephone.Size = New System.Drawing.Size(50, 20)
        Me.txtTelephone.TabIndex = 2
        '
        'txtRoomService
        '
        Me.txtRoomService.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtRoomService.Location = New System.Drawing.Point(115, 38)
        Me.txtRoomService.Name = "txtRoomService"
        Me.txtRoomService.Size = New System.Drawing.Size(50, 20)
        Me.txtRoomService.TabIndex = 1
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(88, 558)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(75, 23)
        Me.btnCalculate.TabIndex = 4
        Me.btnCalculate.Text = "Calculate Changes"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(246, 558)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 5
        Me.btnClear.Text = "Clea&r"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(385, 558)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 6
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblHighlanderHotel
        '
        Me.lblHighlanderHotel.AutoSize = True
        Me.lblHighlanderHotel.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHighlanderHotel.Location = New System.Drawing.Point(152, 19)
        Me.lblHighlanderHotel.Name = "lblHighlanderHotel"
        Me.lblHighlanderHotel.Size = New System.Drawing.Size(210, 29)
        Me.lblHighlanderHotel.TabIndex = 0
        Me.lblHighlanderHotel.Text = "Highlander Hotel"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(522, 665)
        Me.Controls.Add(Me.lblHighlanderHotel)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupgrpBox1)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.grpTotalCharges)
        Me.Controls.Add(Me.lblTimeToday)
        Me.Controls.Add(Me.lblDateToday)
        Me.Controls.Add(Me.lblTimeText)
        Me.Controls.Add(Me.lblTodaydateText)
        Me.Name = "Form1"
        Me.Text = "Room Charge Calculator"
        Me.grpTotalCharges.ResumeLayout(False)
        Me.grpTotalCharges.PerformLayout()
        Me.GroupgrpBox1.ResumeLayout(False)
        Me.GroupgrpBox1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblTodaydateText As System.Windows.Forms.Label
    Friend WithEvents lblTimeText As System.Windows.Forms.Label
    Friend WithEvents lblRoomchargesText As System.Windows.Forms.Label
    Friend WithEvents lblAdditionalchargeText As System.Windows.Forms.Label
    Friend WithEvents lblSubtotalText As System.Windows.Forms.Label
    Friend WithEvents lblTaxText As System.Windows.Forms.Label
    Friend WithEvents lblTotalchargesText As System.Windows.Forms.Label
    Friend WithEvents lblDateToday As System.Windows.Forms.Label
    Friend WithEvents lblTimeToday As System.Windows.Forms.Label
    Friend WithEvents lblRoominfoText As System.Windows.Forms.Label
    Friend WithEvents lblNightsText As System.Windows.Forms.Label
    Friend WithEvents lblNightlycharge As System.Windows.Forms.Label
    Friend WithEvents lblTelephoneText As System.Windows.Forms.Label
    Friend WithEvents lblRoomService As System.Windows.Forms.Label
    Friend WithEvents lblMiscText As System.Windows.Forms.Label
    Friend WithEvents grpTotalCharges As System.Windows.Forms.GroupBox
    Friend WithEvents GroupgrpBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtNights As System.Windows.Forms.TextBox
    Friend WithEvents txtNightlyCharge As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtMisc As System.Windows.Forms.TextBox
    Friend WithEvents txtTelephone As System.Windows.Forms.TextBox
    Friend WithEvents txtRoomService As System.Windows.Forms.TextBox
    Friend WithEvents btnCalculate As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents lblHighlanderHotel As System.Windows.Forms.Label
    Friend WithEvents lblTotal As System.Windows.Forms.Label
    Friend WithEvents lblTax As System.Windows.Forms.Label
    Friend WithEvents lblSubTotal As System.Windows.Forms.Label
    Friend WithEvents lblAddCharges As System.Windows.Forms.Label
    Friend WithEvents lblRoomCharges As System.Windows.Forms.Label

End Class
