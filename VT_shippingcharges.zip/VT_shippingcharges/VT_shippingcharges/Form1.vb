﻿Public Class Form1


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim sngDistance As Single
        Dim sngWeight As Single
        Dim sngRate As Single
        Dim sngTotalCost As Single
        lblTotalCost.Visible = True
        Try
            sngDistance = CSng(txtDistance.Text)
            sngWeight = CSng(txtWeight.Text)
            If sngDistance <= 10 OrElse sngDistance >= 3000 Then
                MessageBox.Show("Your distance is out of our shipping range")
            ElseIf sngWeight <= 0 OrElse sngWeight > 20 Then
                MessageBox.Show("Your package weight is out of our range")
            ElseIf sngWeight <= 2 Then
                sngRate = 0.01
            ElseIf sngWeight > 2 And sngWeight <= 6 Then
                sngRate = 0.015
            ElseIf sngWeight > 6 And sngWeight <= 10 Then
                sngRate = 0.02
            ElseIf sngWeight > 10 And sngWeight <= 20 Then
                sngRate = 0.025

            End If
        Catch ex As InvalidCastException
            MessageBox.Show("Please enter numeric values")
        End Try
        sngTotalCost = sngDistance * sngRate
        lblTotalCost.Text = sngTotalCost.ToString("c")
    End Sub
    Private Sub txtDistance_Click(sender As Object, e As EventArgs) Handles txtDistance.Click
        txtDistance.Text = String.Empty
        'Clear distance input
    End Sub
    Private Sub txtWeight_Click(sender As Object, e As EventArgs) Handles txtWeight.Click
        txtWeight.Text = String.Empty
        'Clear weight input
    End Sub
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
